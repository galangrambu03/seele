import 'dart:async';

import 'package:flutter/foundation.dart';

import '../repositories/quest_repository.dart';

enum QuestRunStatus { idle, running, paused, completed, error }

class QuestRun {
  final String questId;
  final QuestRunStatus status;
  final String message;

  const QuestRun({
    required this.questId,
    required this.status,
    required this.message,
  });
}

class QuestEngine extends ChangeNotifier {
  final QuestRepository repository;

  final Map<String, Timer> _timers = {};
  final Map<String, QuestRun> _runs = {};
  final List<String> _logs = [];

  QuestEngine({required this.repository});

  List<String> get logs => List.unmodifiable(_logs);

  QuestRun? getRun(String questId) => _runs[questId];

  void _log(String message) {
    final time = DateTime.now().toLocal().toString().substring(11, 19);
    _logs.insert(0, '[$time] $message');

    if (_logs.length > 100) {
      _logs.removeLast();
    }

    notifyListeners();
  }

  void _setStatus(String questId, QuestRunStatus status, String message) {
    _runs[questId] = QuestRun(
      questId: questId,
      status: status,
      message: message,
    );

    notifyListeners();
  }

  bool start(String questId) {
    if (repository is! QuestProgressWriter) {
      _setStatus(
        questId,
        QuestRunStatus.error,
        'Repository tidak mendukung update progress',
      );
      return false;
    }

    final quest = repository.getQuestById(questId);

    if (quest == null ||
        quest.targetSeconds == null ||
        quest.targetSeconds! <= 0) {
      _setStatus(
        questId,
        QuestRunStatus.error,
        'Task tidak memiliki target durasi',
      );
      return false;
    }

    if (quest.isCompleted) {
      _setStatus(questId, QuestRunStatus.completed, 'Task sudah selesai');
      return false;
    }

    if (_timers.containsKey(questId)) return false;

    _setStatus(questId, QuestRunStatus.running, 'Task sedang berjalan');
    _log('Memulai task: ${quest.title}');

    _timers[questId] = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _tick(questId),
    );

    return true;
  }

  void _tick(String questId) {
    final writer = repository as QuestProgressWriter;
    final quest = repository.getQuestById(questId);

    if (quest == null || quest.targetSeconds == null) {
      stop(questId);
      return;
    }

    writer.updateProgress(questId, quest.completedSeconds + 1);

    final updated = repository.getQuestById(questId);

    if (updated == null || updated.isCompleted) {
      _timers.remove(questId)?.cancel();
      _setStatus(questId, QuestRunStatus.completed, 'Task selesai');
      _log('Task selesai: ${quest.title}');
    }
  }

  void pause(String questId) {
    if (_runs[questId]?.status != QuestRunStatus.running) return;

    _timers.remove(questId)?.cancel();
    _setStatus(questId, QuestRunStatus.paused, 'Task dijeda');
    _log('Task dijeda: $questId');
  }

  void resume(String questId) {
    if (_runs[questId]?.status != QuestRunStatus.paused) return;
    start(questId);
  }

  void stop(String questId) {
    _timers.remove(questId)?.cancel();
    _setStatus(questId, QuestRunStatus.idle, 'Task dihentikan');
    _log('Task dihentikan: $questId');
  }

  @override
  void dispose() {
    for (final timer in _timers.values) {
      timer.cancel();
    }

    _timers.clear();
    super.dispose();
  }
}
