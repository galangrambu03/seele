import '../../domain/entities/quest_entity.dart';
import '../../domain/repositories/quest_repository.dart';
import '../mappers/quest_mapper.dart';
import '../parsers/quest_parser.dart';

class ParsedQuestRepository extends QuestRepository
    implements QuestProgressWriter {
  final List<Quest> _quests;

  ParsedQuestRepository.fromRawData(dynamic rawData)
    : _quests = QuestMapper.toEntities(QuestParser.parseList(rawData));

  @override
  bool get isMockDataSource => true;

  @override
  String get dataSourceLabel => 'Parsed JSON Data • No live Discord connection';

  @override
  List<Quest> getAllQuests() => List.unmodifiable(_quests);

  @override
  Quest? getQuestById(String id) {
    for (final quest in _quests) {
      if (quest.id == id) return quest;
    }
    return null;
  }

  @override
  int getTotalQuestsCount() => _quests.length;

  @override
  int getAvailableQuestsCount() =>
      _quests.where((q) => q.status == QuestStatus.available).length;

  @override
  int getInProgressQuestsCount() =>
      _quests.where((q) => q.status == QuestStatus.inProgress).length;

  @override
  int getCompletedQuestsCount() =>
      _quests.where((q) => q.status == QuestStatus.completed).length;

  @override
  void updateProgress(String questId, int completedSeconds) {
    final index = _quests.indexWhere((q) => q.id == questId);
    if (index == -1) return;

    final current = _quests[index];
    final target = current.targetSeconds;
    if (target == null || target <= 0) return;

    final seconds = completedSeconds.clamp(0, target);
    final progress = seconds / target;

    _quests[index] = Quest(
      id: current.id,
      title: current.title,
      description: current.description,
      category: current.category,
      status: progress >= 1 ? QuestStatus.completed : QuestStatus.inProgress,
      rewardOrbs: current.rewardOrbs,
      duration: current.duration,
      progress: progress,
      requirements: current.requirements,
      taskType: current.taskType,
      targetSeconds: target,
      completedSeconds: seconds,
      taskMetadata: current.taskMetadata,
    );

    notifyListeners();
  }
}
